/** Automatically generated file. DO NOT MODIFY */
package org.bluetooth.bledemo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}