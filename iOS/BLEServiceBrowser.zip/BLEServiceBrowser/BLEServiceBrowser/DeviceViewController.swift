//
//  DeviceViewController.swift
//  BLEServiceBrowser
//
//  Created by Spider on 11/4/15.
//  Copyright © 2015 Spider. All rights reserved.
//

import UIKit
import CoreBluetooth

class DeviceViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, SelectionDelegate, UISplitViewControllerDelegate {

    @IBOutlet weak var detailDescriptionLabel: UILabel!
    @IBOutlet weak var connectionStatusLabel: UILabel!
    
    @IBOutlet weak var statusLabel: UILabel!
    @IBOutlet weak var serviceLabel: UILabel!
    @IBOutlet weak var serviceTableViewOutlet: UITableView!
    
    @IBOutlet weak var connectButton: UIBarButtonItem!
    var objects :NSMutableArray = []
    var adapter: BLEAdapter!
    var peripheral: CBPeripheral!
    var detailItem: AnyObject!
    var masterPopoverController: UIPopoverController?
    var delegate: SelectionDelegate?
    

    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
        appDelegate.setMainViewDelegate(self)
        
        self.detailDescriptionLabel.text = "";
        adapter = sharedBLEAdapter
        adapter.dvController = self
        configureView()
        self.connectionStatusLabel.text = "Not Connected"
        
        
    }
    
    override func viewWillAppear(animated: Bool) {
        adapter = sharedBLEAdapter
        adapter.dvController = self
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if(segue.identifier == "showService")
        {
            let serviceCtrl = segue.destinationViewController as! ServiceViewController
            let indexPath = self.serviceTableViewOutlet.indexPathForSelectedRow! as NSIndexPath
            let serviceObject = objects.objectAtIndex(indexPath.row) as! CBService
            serviceCtrl.service = serviceObject
            
            
            //            detailCtrl.photoInfo = mArrayPhotos.objectAtIndex(nSelectedIdx) as! PhotoInfo
            
            
        }
    }
    
    func setDetailItems (newDetailItem: AnyObject?){
        peripheral = newDetailItem as! CBPeripheral
//        self.configureView()
        
        
    }
    
    func configureView(){
        adapter.dvController = self
        if(peripheral != nil){
            self.clearUI(false)
            
            self.detailDescriptionLabel.text = peripheral.description
            self.detailDescriptionLabel.layer.borderColor = UIColor.greenColor().CGColor
            self.detailDescriptionLabel.layer.borderWidth = 1.0;
        }
    }
    
    func clearUI(clear: Bool){
        if(clear == true){
            self.serviceTableViewOutlet.hidden = true
            self.navigationItem.rightBarButtonItem = nil
            self.detailDescriptionLabel.hidden = true
            self.connectionStatusLabel.hidden = true
            self.statusLabel.hidden = true
            self.serviceLabel.hidden = true
//            self.noDevicesLabel.hidden = true
            objects.removeAllObjects()
            self.serviceTableViewOutlet.reloadData()
        }
        else
        {
            self.serviceTableViewOutlet.hidden = false
            self.navigationItem.rightBarButtonItem = connectButton
            self.detailDescriptionLabel.hidden = false
            self.connectionStatusLabel.hidden = false
            self.statusLabel.hidden = false
            self.serviceLabel.hidden = false
            //            self.noDevicesLabel.hidden = true
            objects.removeAllObjects()
            self.serviceTableViewOutlet.reloadData()
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return objects.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("deviceCell")! as UITableViewCell
        let aService = objects.objectAtIndex(indexPath.row) as! CBService
        
        cell.textLabel?.text = adapter.GetServiceName(aService.UUID)
        cell.detailTextLabel?.text = aService.UUID.data.description
        
        return cell
    }
    
//    func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
//        return false
//    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        if(UIDevice.currentDevice().userInterfaceIdiom == UIUserInterfaceIdiom.Pad)
        {
            let object = objects.objectAtIndex(indexPath.row) as! CBService
            
        }
    }
    

    
    @IBAction func connectButtonPressed(sender: AnyObject) {
        if(peripheral.state == CBPeripheralState.Disconnected)
        {
            objects.removeAllObjects()
            serviceTableViewOutlet.reloadData()
            adapter.connectPeripheral(peripheral, status: true)
        }
        else
        {
            adapter.connectPeripheral(peripheral, status: false)
        }
    }
    
    func OnDiscoverService(services: NSArray)
    {
//        let service: CBService!
        for service in services
        {
//            objects.insertObject(<#T##anObject: AnyObject##AnyObject#>, atIndex: <#T##Int#>)
            objects.insertObject(service, atIndex: 0)
            let indexPath = NSIndexPath(forRow: 0, inSection: 0)
            var indxesPath:[NSIndexPath] = [NSIndexPath]()
            indxesPath.append(indexPath)
            
//            self.serviceTableViewOutlet.numberOfRowsInSection(0) = self.serviceTableViewOutlet.numberOfRowsInSection(0) + 1;
            serviceTableViewOutlet.beginUpdates()
            serviceTableViewOutlet.insertRowsAtIndexPaths(indxesPath, withRowAnimation: UITableViewRowAnimation.Automatic)
            serviceTableViewOutlet.endUpdates()
        }
    }
    
    func OnConnected(status: Bool){
        if(status == true)
        {
            connectionStatusLabel.text = "Connected"
            connectButton = UIBarButtonItem(title: "Disconnect", style: UIBarButtonItemStyle.Plain, target: self, action: "connectButtonPressed:")
        }
        else
        {
            connectionStatusLabel.text = "Not Connected";
            connectButton = UIBarButtonItem(title: "Connect", style: UIBarButtonItemStyle.Plain, target: self, action: "connectButtonPressed:")
        }
    }
    
    // mark Selection Delegate
    
    func ClearUI(clear: Bool)
    {
        
    }
    
    func selectedPeripheral(peripheral: CBPeripheral)
    {
        self.peripheral = peripheral
        self.configureView()
    }
    
    func selectedService(service: CBService)
    {
        
    }
    
    func selectedCharacteristic(characteristic: CBCharacteristic)
    {
        
    }
    
    // mark Split View
    
    func splitViewController(svc: UISplitViewController, willHideViewController aViewController: UIViewController, withBarButtonItem barButtonItem: UIBarButtonItem, forPopoverController pc: UIPopoverController) {
        
        barButtonItem.title = "Scan"
        self.navigationItem.setLeftBarButtonItem(barButtonItem, animated: true)
        self.navigationItem.leftItemsSupplementBackButton = true
        self.masterPopoverController = pc
    }
    
    func splitViewController(svc: UISplitViewController, willShowViewController aViewController: UIViewController, invalidatingBarButtonItem barButtonItem: UIBarButtonItem) {
        self.navigationItem.setLeftBarButtonItem(nil, animated: true)
        self.masterPopoverController = nil
    }

}
