//
//  MainViewController.swift
//  BLEServiceBrowser
//
//  Created by Spider on 11/4/15.
//  Copyright © 2015 Spider. All rights reserved.
//

import UIKit
import CoreBluetooth

class MainViewController: UITableViewController {
    
//    var adapter: BLEAdapter
    var objects :NSMutableArray = []
    var adapter: BLEAdapter!
    var scanState: Bool?
    var delegate: SelectionDelegate?

    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
        adapter = sharedBLEAdapter
        adapter.controlSetup(1)
        scanState = false

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return objects.count
//        return 0;
    }

   
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCellWithIdentifier("Cell", forIndexPath: indexPath)
        let blObject = objects.objectAtIndex(indexPath.row) as! CBPeripheral
        if(blObject.name != nil)
        {
            cell.textLabel?.text = blObject.name
        }
        else
        {
            cell.textLabel?.text = blObject.name
        }
//        cell.textLabel?.text = "Heart Rate Monitor"

        return cell
    }
    

    
    // Override to support conditional editing of the table view.
    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }


    /*
    // Override to support editing the table view.
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if editingStyle == .Delete {
            // Delete the row from the data source
            tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
        } else if editingStyle == .Insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(tableView: UITableView, moveRowAtIndexPath fromIndexPath: NSIndexPath, toIndexPath: NSIndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(tableView: UITableView, canMoveRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

//    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
//        if(UIDevice.currentDevice().userInterfaceIdiom == UIUserInterfaceIdiom.Pad)
//        {
//            let blObject = objects.objectAtIndex(indexPath.row) as! CBPeripheral
//        }
//    }
//   
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if(segue.identifier == "showDetail")
        {
            let detailCtrl = segue.destinationViewController as! DeviceViewController
            let indexPath = self.tableView.indexPathForSelectedRow! as NSIndexPath
            let blObject = objects.objectAtIndex(indexPath.row) as! CBPeripheral
            detailCtrl.setDetailItems(blObject)
          
            
//            detailCtrl.photoInfo = mArrayPhotos.objectAtIndex(nSelectedIdx) as! PhotoInfo
            
            
        }
    }
   
    
    func insertNewObject(sender:AnyObject){
        objects.insertObject(NSDate(), atIndex: 0)
        let indexPath = NSIndexPath(forRow: 0, inSection: 0)
        var indxesPath:[NSIndexPath] = [NSIndexPath]()
        indxesPath.append(indexPath)
        self.tableView.insertRowsAtIndexPaths(indxesPath, withRowAnimation: UITableViewRowAnimation.Automatic)
        
        
    }
    
    func insertScannedperipherals()
    {
        for i in 0...adapter.peripherals.count - 1
        {
            objects.insertObject(adapter.peripherals.objectAtIndex(i), atIndex: 0)
            let indexPath = NSIndexPath(forRow: 0, inSection: 0)
            var indxesPath:[NSIndexPath] = [NSIndexPath]()
            indxesPath.append(indexPath)
            self.tableView.insertRowsAtIndexPaths(indxesPath, withRowAnimation: UITableViewRowAnimation.Automatic)
        }
    }

    @IBAction func onScanDevices(sender: AnyObject) {
        
        if(scanState == false)
        {
            objects.removeAllObjects()
            self.tableView.reloadData()
            let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
            UIApplication.sharedApplication().networkActivityIndicatorVisible = true;
            
            if(adapter.activePeripheral != nil)
            {
                if(adapter.activePeripheral!.state != CBPeripheralState.Disconnected)
                {
                    adapter.CM!.cancelPeripheralConnection(adapter.activePeripheral!)
                }
            }
            
            adapter.peripherals.removeAllObjects()
            
//            if(adapter.peripherals != nil)
//            {
//                
//            }
            
            adapter.findBLEPeripherals(2)
            
            NSTimer.scheduledTimerWithTimeInterval(2.0, target: self, selector: "connectionTimer:", userInfo: nil, repeats: false)
            
        }
    }
    
    func connectionTimer(timer: NSTimer)
    {
        if(adapter.peripherals.count > 0)
        {
            adapter.printKnownPeripherals()
            if(adapter.peripherals.count > 0)
            {
                insertScannedperipherals()
            }
        }
        
        
        UIApplication.sharedApplication().networkActivityIndicatorVisible = false;
    }
}
