//
//  TestService.swift
//  BLEServiceBrowser
//
//  Created by Spider on 11/10/15.
//  Copyright © 2015 Spider. All rights reserved.
//

import UIKit

class TestService: NSObject {
    
    var title: NSString?
    var uuid: NSString?
    
    func initWithParams(titleParam: NSString, uuidData: NSString) -> TestService
    {
        title = titleParam
        uuid = uuidData
        
        return self
    }

}
