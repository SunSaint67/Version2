//
//  BLEAdapter.swift
//  BLEServiceBrowser
//
//  Created by Spider on 11/7/15.
//  Copyright © 2015 Spider. All rights reserved.
//

import UIKit
import CoreBluetooth

let sharedBLEAdapter = BLEAdapter()

protocol BLEAdapterDelegate{
    func OnDiscoverServices(s: NSArray)
    func OnConnected(status: Bool)
}

class BLEAdapter: NSObject,CBCentralManagerDelegate, CBPeripheralDelegate {
    
    var CM: CBCentralManager?
    var activePeripheral: CBPeripheral?
    var peripherals: NSMutableArray = []
    
    var dvController: DeviceViewController?
    var svController: ServiceViewController?
    var cvController: CharViewController?

    func sharedInstance() -> BLEAdapter{
        
        return sharedBLEAdapter
    }
    
//    func writeValue(serviceUUID: Int, characteristicUUID charUUID : Int, peripheral p: CBPeripheral, dataValue data : NSData?)
//    {
//        let s = self.swap(serviceUUID as! UInt16) as UInt16
//        let c = self.swap(charUUID as! UInt16) as UInt16
//        let sd = NSData(bytes: s, length: 2)
//    }
    class func writeCharacteristic(peripheral:CBPeripheral, sUUID: String, cUUID: String, data: NSData){
        for service in peripheral.services! as [CBService] {
            if(service.UUID == CBUUID(string: sUUID)){
                for characteristic in service.characteristics! as [CBCharacteristic]{
                    if(characteristic.UUID == CBUUID(string: cUUID)){
                        /* Everything is found, WRITE characteristic ! */
                        peripheral.writeValue(data, forCharacteristic: characteristic, type: CBCharacteristicWriteType.WithResponse)
                    }
                }
            }
        }
    }
    
    
    class func writeCharacteristicCBUUID(peripheral:CBPeripheral, sUUID: CBUUID, cUUID: CBUUID, data: NSData){
        for service in peripheral.services! as [CBService] {
            if(service.UUID == sUUID){
                for characteristic in service.characteristics! as [CBCharacteristic]{
                    if(characteristic.UUID == cUUID){
                        /* Everything is found, WRITE characteristic ! */
                        peripheral.writeValue(data, forCharacteristic: characteristic, type: CBCharacteristicWriteType.WithResponse)
                    }
                }
            }
        }
    }
    
    class func setNotificationForCharacteristic(peripheral:CBPeripheral, sUUID: String, cUUID: String, enable: Bool){
        for service in peripheral.services! as [CBService] {
            if(service.UUID == CBUUID(string: sUUID)){
                for characteristic in service.characteristics! as [CBCharacteristic]{
                    if(characteristic.UUID == CBUUID(string: cUUID)){
                        /* Everything is found, SET notification ! */
                        peripheral.setNotifyValue(enable, forCharacteristic: characteristic)
                    }
                }
            }
        }
    }
    
    class func setNotificationForCharacteristicUUID(peripheral:CBPeripheral, sUUID: CBUUID, cUUID: CBUUID, enable: Bool){
        for service in peripheral.services! as [CBService] {
            if(service.UUID == sUUID){
                for characteristic in service.characteristics! as [CBCharacteristic]{
                    if(characteristic.UUID == cUUID){
                        /* Everything is found, set notification ! */
                        peripheral.setNotifyValue(enable, forCharacteristic: characteristic)
                    }
                }
            }
        }
    }
    
    
    
    func swap(s: UInt16)->UInt16
    {
        var temp = s << 8 as UInt16
        temp |= (s >> 8)
        
        return temp
    }
    
    func controlSetup(s: Int)->Int
    {
        self.CM = CBCentralManager(delegate: self, queue: nil, options: [CBCentralManagerOptionRestoreIdentifierKey:"BLESericeBrowser"])
        
        return 0
    }
    
    func findBLEPeripherals(timeout: Int)->Int
    {
        if(self.CM?.state != CBCentralManagerState.PoweredOn)
        {
            print("CoreBluetooth not correctly initialized !\r\n");
            print("State = %d (%s)\r\n",self.CM!.state,self.centralManagerStateToString(self.CM!.state));
            return -1
        }
//        NSTimer.scheduledTimerWithTimeInterval((timeout as? Double)!, target: self, selector: "scanTimer:", userInfo: nil, repeats: false)
        
        NSTimer.scheduledTimerWithTimeInterval(2.0, target: self, selector: "scanTimer:", userInfo: nil, repeats: false)
        
        self.CM?.scanForPeripheralsWithServices(nil, options: nil)
        return 0
        
    }
    
    func centralManagerStateToString(state: CBCentralManagerState)->[CChar]?
    {
        var returnVal = "Unknown state"
        
        if(state == CBCentralManagerState.Unknown)
        {
            returnVal = "State unknown (CBCentralManagerStateUnknown)"
        }
        else if(state == CBCentralManagerState.Resetting)
        {
            returnVal = "State resetting (CBCentralManagerStateUnknown)"
        }
        else if(state == CBCentralManagerState.Unsupported)
        {
            returnVal = "State BLE unsupported (CBCentralManagerStateResetting)"
        }
        else if(state == CBCentralManagerState.Unauthorized)
        {
            returnVal = "State unauthorized (CBCentralManagerStateUnauthorized)"
        }
        else if(state == CBCentralManagerState.PoweredOff)
        {
            returnVal = "State BLE powered off (CBCentralManagerStatePoweredOff)"
        }
        else if(state == CBCentralManagerState.PoweredOn)
        {
            returnVal = "State powered up and ready (CBCentralManagerStatePoweredOn)"
        }
        else
        {
            returnVal = "State unknown"
        }
        
        return (returnVal.cStringUsingEncoding(NSUTF8StringEncoding))
    }
    
    
    /*!
    *  @method scanTimer:
    *
    *  @param timer Backpointer to timer
    *
    *  @discussion scanTimer is called when findBLEPeripherals has timed out, it stops the CentralManager from scanning further and prints out information about known peripherals
    *
    */
    
    func scanTimer(timer: NSTimer)
    {
        self.CM?.stopScan()
        print("Stopped Scanning\r\n");
        print("Known peripherals : %d\r\n",self.peripherals.count);
        self.printKnownPeripherals()
        
    }
    
    /*!
    *  @method printKnownPeripherals:
    *
    *  @discussion printKnownPeripherals prints all curenntly known peripherals stored in the peripherals array of TIBLECBKeyfob class
    *
    */
    
    func printKnownPeripherals(){
        print("List of currently known peripherals : \r\n");
        let count = self.peripherals.count
        if(count > 0)
        {
            for i in 0...count - 1
            {
                let p = self.peripherals.objectAtIndex(i) as! CBPeripheral
                self.printPeripheralInfo(p)
            }
        }
        
    }
    
    func printPeripheralInfo(peripheral: CBPeripheral)
    {
        print("------------------------------------\r\n");
        print("Peripheral Info :\r\n");
        
        print("RSSI : %d\r\n",peripheral.RSSI?.intValue);
        print("Name : %s\r\n", peripheral.name?.cStringUsingEncoding(NSUTF8StringEncoding));
        print("isConnected : %d\r\n",peripheral.state);
        print("-------------------------------------\r\n");
    }
    
    func getAllCharacteristicsForService(p: CBPeripheral, service: CBService)
    {
        p.discoverCharacteristics(nil, forService: service)
    }

    
    func connectPeripheral(peripheral: CBPeripheral, status: Bool)
    {
        if(status == true)
        {
            print("Connecting to peripheral with UUID : %s\r\n", peripheral.identifier.UUIDString.utf8)
            activePeripheral = peripheral
            activePeripheral?.delegate = self
            CM?.connectPeripheral(activePeripheral!, options: nil)
        }
        else
        {
            activePeripheral = peripheral
            activePeripheral?.delegate = self
            CM?.cancelPeripheralConnection(self.activePeripheral!)
        }
    }
    
    func CBUUIDToString(UUID: CBUUID)->[CChar]?{
        return UUID.data.description.cStringUsingEncoding(NSUTF8StringEncoding)
    }
    
    func GetServiceName(UUID: CBUUID)->String{
        
        let uuid = self.CBUUIDToInt(UUID) as UInt16
        switch(uuid)
        {
        case 0x1800: return "Generic Access"
        case 0x1801: return "Generic Attribute"
        case 0x1802: return "Immediate Alert"
        case 0x1803: return "Link Loss"
        case 0x1804: return "Tx Power"
        case 0x1805: return "Current Time Service"
        case 0x1806: return "Reference Time Update Service"
        case 0x1807: return "Next DST Change Service"
        case 0x1808: return "Glucose"
        case 0x1809: return "Health Thermometer"
        case 0x180A: return "Device Information"
        case 0x180B: return "Network Availability Service"
        case 0x180C: return "Watchdog"
        case 0x180D: return "Heart Rate"
        case 0x180E: return "Phone Alert Status Service"
        case 0x180F: return "Battery Service"
        case 0x1810: return "Blood Pressure"
        case 0x1811: return "Alert Notification Service"
        case 0x1812: return "Human Interface Device"
        case 0x1813: return "Scan Parameters"
        case 0x1814: return "RUNNING SPEED AND CADENCE"
        case 0x1815: return "Automation IO"
        case 0x1816: return "Cycling Speed and Cadence"
        case 0x1817: return "Pulse Oximeter"
        case 0x1818: return "Cycling Power Service"
        case 0x1819: return "Location and Navigation Service"
        case 0x181A: return "Continous Glucose Measurement Service"
        case 0x2A00: return "Device Name"
        case 0x2A01: return "Appearance"
        case 0x2A02: return "Peripheral Privacy Flag"
        case 0x2A03: return "Reconnection Address"
        case 0x2A04: return "Peripheral Preferred Connection Parameters"
        case 0x2A05: return "Service Changed"
        case 0x2A06: return "Alert Level"
        case 0x2A07: return "Tx Power Level"
        case 0x2A08: return "Date Time"
        case 0x2A09: return "Day of Week"
        case 0x2A0A: return "Day Date Time"
        case 0x2A0B: return "Exact Time 100"
        case 0x2A0C: return "Exact Time 256"
        case 0x2A0D: return "DST Offset"
        case 0x2A0E: return "Time Zone"
        case 0x2A0F: return "Local Time Information"
        case 0x2A10: return "Secondary Time Zone"
        case 0x2A11: return "Time with DST"
        case 0x2A12: return "Time Accuracy"
        case 0x2A13: return "Time Source"
        case 0x2A14: return "Reference Time Information"
        case 0x2A15: return "Time Broadcast"
        case 0x2A16: return "Time Update Control Point"
        case 0x2A17: return "Time Update State"
        case 0x2A18: return "Glucose Measurement"
        case 0x2A19: return "Battery Level"
        case 0x2A1A: return "Battery Power State"
        case 0x2A1B: return "Battery Level State"
        case 0x2A1C: return "Temperature Measurement"
        case 0x2A1D: return "Temperature Type"
        case 0x2A1E: return "Intermediate Temperature"
        case 0x2A1F: return "Temperature in Celsius"
        case 0x2A20: return "Temperature in Fahrenheit"
        case 0x2A21: return "Measurement Interval"
        case 0x2A22: return "Boot Keyboard Input Report"
        case 0x2A23: return "System ID"
        case 0x2A24: return "Model Number String"
        case 0x2A25: return "Serial Number String"
        case 0x2A26: return "Firmware Revision String"
        case 0x2A27: return "Hardware Revision String"
        case 0x2A28: return "Software Revision String"
        case 0x2A29: return "Manufacturer Name String"
        case 0x2A2A: return "IEEE 11073-20601 Regulatory Certification Data List"
        case 0x2A2B: return "Current Time"
        case 0x2A2C: return "Elevation"
        case 0x2A2D: return "Latitude"
        case 0x2A2E: return "Longitude"
        case 0x2A2F: return "Position 2D"
        case 0x2A30: return "Position 3D"
        case 0x2A31: return "Scan Refresh"
        case 0x2A32: return "Boot Keyboard Output Report"
        case 0x2A33: return "Boot Mouse Input Report"
        case 0x2A34: return "Glucose Measurement Context"
        case 0x2A35: return "Blood Pressure Measurement"
        case 0x2A36: return "Intermediate Cuff Pressure"
        case 0x2A37: return "Heart Rate Measurement"
        case 0x2A38: return "Body Sensor Location"
        case 0x2A39: return "Heart Rate Control Point"
        case 0x2A3A: return "Removable"
        case 0x2A3B: return "Service Required"
        case 0x2A3C: return "Scientific Temperature in Celsius"
        case 0x2A3D: return "String"
        case 0x2A3E: return "Network Availability"
        case 0x2A3F: return "Alert Status"
        case 0x2A40: return "Ringer Control Point"
        case 0x2A41: return "Ringer Setting"
        case 0x2A42: return "Alert Category ID Bit Mask"
        case 0x2A43: return "Alert Category ID"
        case 0x2A44: return "Alert Notification Control Point"
        case 0x2A45: return "Unread Alert Status"
        case 0x2A46: return "New Alert"
        case 0x2A47: return "Supported New Alert Category"
        case 0x2A48: return "Supported Unread Alert Category"
        case 0x2A49: return "Blood Pressure Feature"
        case 0x2A4A: return "HID Information"
        case 0x2A4B: return "Report Map"
        case 0x2A4C: return "HID Control Point"
        case 0x2A4D: return "Report"
        case 0x2A4E: return "Protocol Mode"
        case 0x2A4F: return "Scan Interval Window"
        case 0x2A50: return "PnP ID"
        case 0x2A51: return "Glucose Features"
        case 0x2A52: return "Record Access Control Point"
        case 0x2A53: return "RSC Measurement"
        case 0x2A54: return "RSC Feature"
        case 0x2A55: return "SC Control Point"
        case 0x2A56: return "Digital Input"
        case 0x2A57: return "Digital Output"
        case 0x2A58: return "Analog Input"
        case 0x2A59: return "Analog Output"
        case 0x2A5A: return "Aggregate Input"
        case 0x2A5B: return "CSC Measurement"
        case 0x2A5C: return "CSC Feature"
        case 0x2A5D: return "Sensor Location"
        case 0x2A5E: return "Pulse Oximetry Spot-check Measurement"
        case 0x2A5F: return "Pulse Oximetry Continuous Measurement"
        case 0x2A60: return "Pulse Oximetry Pulsatile Event"
        case 0x2A61: return "Pulse Oximetry Features"
        case 0x2A62: return "Pulse Oximetry Control Point"
        case 0x2A63: return "Cycling Power Measurement Characteristic"
        case 0x2A64: return "Cycling Power Vector Characteristic"
        case 0x2A65: return "Cycling Power Feature Characteristic"
        case 0x2A66: return "Cycling Power Control Point Characteristic"
        case 0x2A67: return "Location and Speed Characteristic"
        case 0x2A68: return "Navigation Characteristic"
        case 0x2A69: return "Position Quality Characteristic"
        case 0x2A6A: return "LN Feature Characteristic"
        case 0x2A6B: return "LN Control Point Characteristic"
        case 0x2A6C: return "CGM Measurement Characteristic"
        case 0x2A6D: return "CGM Features Characteristic"
        case 0x2A6E: return "CGM Status Characteristic"
        case 0x2A6F: return "CGM Session Start Time Characteristic"
        case 0x2A70: return "Application Security Point Characteristic"
        case 0x2A71: return "CGM Specific Ops Control Point Characteristic"
        default:
            return "Custom Profile";
            break;
        }
        return ""
    }
    
    func CBUUIDToNSString(UUID: CBUUID)->NSString
    {
        return UUID.data.description
    }
    
    func UUIDToString(UUID: NSUUID?)->[CChar]?{
        if(UUID == nil)
        {
            return  nil
        }
        
        return UUID!.UUIDString.cStringUsingEncoding(NSUTF8StringEncoding)
    }
    
    func compareCBUUID(UUID1: CBUUID, secondUUID  UUID2: CBUUID)->Int
    {
        var b1 = [UInt8](count: 16, repeatedValue: 0)
        UUID1.data.getBytes(&b1, length: 16)
        
        var b2 = [UInt8](count: 16, repeatedValue: 0)
        UUID2.data.getBytes(&b2, length: 16)
        
        if(memcmp(b1, b2, UUID1.data.length) == 0){
            return 1
        }
        else
        {
            return 0
        }
        
        
//        var buffer = [UInt8](count: UUID1.data.length, repeatedValue: 0x00)
//        UUID1.data.getBytes(&buffer, length: buffer.count)
        
        
    }
    
    func compareCBUUIDToInt(UUID1: CBUUID, toInt UUID2: UInt16)->Int{
        let uuid1data = UUID1.data
        let uuid1count = uuid1data.length / sizeof(UInt8)
        var uuid1array = [UInt8](count: uuid1count, repeatedValue: 0)
        uuid1data.getBytes(&uuid1array, length: uuid1count * sizeof(UInt8))
        
        // @todo there's gotta be a better way to do this
        let b2: UInt16 = self.swap(UUID2)
        var b2Array = [b2 & 0xff, (b2 >> 8) & 0xff]
        if memcmp(&uuid1array, &b2Array, 2) == 0 {
            return 1
        }
        return 0
    }
    
    func CBUUIDToInt(UUID: CBUUID)->UInt16
    {
        var b1 = [UInt16](count: 16, repeatedValue: 0)
        UUID.data.getBytes(&b1, length: 16)
        let nUUID = (((UInt16)(b1[0]) << 8) | (UInt16)(b1[1]))
        return nUUID
    }
    
//    func IntToCBUUID(UUID: UInt16)->CBUUID
//    {
//        var t: Array<CChar> = Array(count: 16, repeatedValue: 32)
//        t[0] = ((UUID >> 8) & 0xff)
//        t[1] = (UUID & 0xff)
//    }
    /*
    *  @method findServiceFromUUID:
    *
    *  @param UUID CBUUID to find in service list
    *  @param p Peripheral to find service on
    *
    *  @return pointer to CBService if found, nil if not
    *
    *  @discussion findServiceFromUUID searches through the services list of a peripheral to find a
    *  service with a specific UUID
    *
    */
    func findServiceFromUUID (UUID: CBUUID,  peripheral p: CBPeripheral)->CBService?
    {
        for i in 0...(p.services?.count)! - 1
        {
            let s = p.services![i] as CBService
            if(self.compareCBUUID(s.UUID, secondUUID: UUID) == 1)
            {
                return s
            }
        }
        
        return nil
    }
    /*
    *  @method findCharacteristicFromUUID:
    *
    *  @param UUID CBUUID to find in Characteristic list of service
    *  @param service Pointer to CBService to search for charateristics on
    *
    *  @return pointer to CBCharacteristic if found, nil if not
    *
    *  @discussion findCharacteristicFromUUID searches through the characteristic list of a given service
    *  to find a characteristic with a specific UUID
    *
    */
    func findCharacteristicFromUUID (UUID: CBUUID, Service  service: CBService)->CBCharacteristic?{
        for i in 0...(service.characteristics?.count)! - 1
        {
            let c = service.characteristics![i] as CBCharacteristic
            if(self.compareCBUUID(c.UUID, secondUUID: UUID) == 1)
            {
                return c
            }
        }
        
        return nil
    }
    
    // mark

    func centralManagerDidUpdateState(central: CBCentralManager) {
        print("Status of CoreBluetooth central manager changed %d (%s)\r\n",central.state,self.centralManagerStateToString(central.state));
    }
    
    func centralManager(central: CBCentralManager, willRestoreState dict: [String : AnyObject]) {
        self.peripherals = dict[CBCentralManagerRestoredStatePeripheralsKey] as! NSMutableArray;
    }
    
    func centralManager(central: CBCentralManager, didDiscoverPeripheral peripheral: CBPeripheral, advertisementData: [String : AnyObject], RSSI: NSNumber) {
        
        if (self.peripherals.count == 0)
        {
            self.peripherals.addObject(peripheral)
        }
        else {
            for i in 0...self.peripherals.count-1
            {
                let p = self.peripherals.objectAtIndex(i)
                if(p.identifier == peripheral.identifier)
                {
                    self.peripherals.replaceObjectAtIndex(i, withObject: peripheral)
                    print("Duplicate UUID found updating ...\r\n");
                    return
                }
                else
                {
                    if(p.name != peripheral.name)
                    {
                        self.peripherals.replaceObjectAtIndex(i, withObject: peripheral)
                        print("Duplicate UUID found updating ...\r\n")
                        return;
                    }
                }
            }
            
            self.peripherals.addObject(peripheral)
            print("New UUID, adding\r\n");
        }
        print("didDiscoverPeripheral\r\n");
        
    }
    
    func centralManager(central: CBCentralManager, didConnectPeripheral peripheral: CBPeripheral) {
        print("Connection to peripheral with UUID : %s successfull\r\n", peripheral.identifier.UUIDString.utf8);
        self.activePeripheral = peripheral;
        
        if(self.dvController != nil)
        {
            self.dvController?.OnConnected(true)
            //        [(DeviceViewController *) [self dvController] OnConnected:TRUE];
        }
        self.activePeripheral?.discoverServices(nil)
        //[self.activePeripheral discoverServices:nil];
    }
    
    func centralManager(central: CBCentralManager, didFailToConnectPeripheral peripheral: CBPeripheral, error: NSError?){
        print("Failed to connect to peripheral %s\r\n",peripheral.identifier.UUIDString.utf8);
        self.activePeripheral = peripheral;
        
        if(self.dvController != nil)
        {
            self.dvController?.OnConnected(false)
            //        [(DeviceViewController *) [self dvController] OnConnected:FALSE];
        }
        
        self.activePeripheral?.discoverServices(nil)
        //[self.activePeripheral discoverServices:nil];
    }
    
    func centralManager(central: CBCentralManager, didDisconnectPeripheral peripheral: CBPeripheral, error: NSError?) {
        print("KeyfobViewController didDisconnectPeripheral");
        
        if(self.dvController != nil)
        {
            self.dvController?.OnConnected(false)
        }
    }
    
    
    //mark CBPeripheralDelegate
    
    func peripheral(peripheral: CBPeripheral, didDiscoverCharacteristicsForService service: CBService, error: NSError?) {
        if ((error == nil)) {
            print("Characteristics of service with UUID : %s found\r\n",self.CBUUIDToString(service.UUID));
            
            if(svController != nil)
            {
                svController?.AlCharacteristics(service.characteristics!)
            }
        }
        else {
            print("Characteristic discorvery unsuccessfull !\r\n");
        }
    }
    
    func peripheral(peripheral: CBPeripheral, didDiscoverDescriptorsForCharacteristic characteristic: CBCharacteristic, error: NSError?) {
        
    }
    
    func peripheral(peripheral: CBPeripheral, didDiscoverIncludedServicesForService service: CBService, error: NSError?) {
        
    }
    
    /*
    *  @method didDiscoverServices
    *
    *  @param peripheral Pheripheral that got updated
    *  @error error Error message if something went wrong
    *
    *  @discussion didDiscoverServices is called when CoreBluetooth has discovered services on a
    *  peripheral after the discoverServices routine has been called on the peripheral
    *
    */
    func peripheral(peripheral: CBPeripheral, didDiscoverServices error: NSError?) {
        if (error == nil) {
            print("Services of peripheral with UUID : %s found\r\n", peripheral.identifier.UUIDString.utf8);
            
            if(dvController != nil)
            {
                dvController?.OnDiscoverService(peripheral.services!)
                //            [(DeviceViewController *) [self dvController] OnDiscoverServices:peripheral.services];
            }
            
            //[self getAllCharacteristicsFromPeripheral:peripheral];
        }
        else {
            print("Service discovery was unsuccessfull !\r\n");
        }
    }
    
    func peripheral(peripheral: CBPeripheral, didUpdateNotificationStateForCharacteristic characteristic: CBCharacteristic, error: NSError?) {
        if (error != nil) {
            print("Updated notification state for characteristic with UUID %s on service with  UUID %s on peripheral with UUID %s\r\n",self.CBUUIDToString(characteristic.UUID),self.CBUUIDToString(characteristic.service.UUID),peripheral.identifier.UUIDString.utf8);
        }
        else {
            print("Error in setting notification state for characteristic with UUID %s on service with  UUID %s on peripheral with UUID %s\r\n",self.CBUUIDToString(characteristic.UUID),self.CBUUIDToString(characteristic.service.UUID),peripheral.identifier.UUIDString.utf8);
            print("Error code was %s\r\n",error!.description.cStringUsingEncoding(NSUTF8StringEncoding));
        }

    }
    
    func peripheral(peripheral: CBPeripheral, didUpdateValueForCharacteristic characteristic: CBCharacteristic, error: NSError?) {
        if (error == nil) {
            print("Services of peripheral with UUID : %s found\r\n",peripheral.identifier.UUIDString.utf8);
            
            if(cvController != nil)
            {
                self.cvController?.OnReadChar(characteristic)
                //            [(CharViewController *) [self cvController] OnReadChar:characteristic];
            }
        }
        else {
            print("updateValueForCharacteristic failed !");
        }
    }
    
    func peripheral(peripheral: CBPeripheral, didWriteValueForCharacteristic characteristic: CBCharacteristic, error: NSError?) {
        
    }
    
    func peripheral(peripheral: CBPeripheral, didWriteValueForDescriptor descriptor: CBDescriptor, error: NSError?) {
        
    }
    
    func peripheralDidUpdateRSSI(peripheral: CBPeripheral, error: NSError?) {
        
    }
    
    
    
    
}
