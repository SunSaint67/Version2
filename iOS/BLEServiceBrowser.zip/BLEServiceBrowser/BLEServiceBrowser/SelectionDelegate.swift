//
//  SelectionDelegate.swift
//  BLEServiceBrowser
//
//  Created by Spider on 11/10/15.
//  Copyright © 2015 Spider. All rights reserved.
//

import Foundation
import CoreBluetooth

protocol SelectionDelegate
{
    func ClearUI(clear: Bool)
    func selectedPeripheral(peripheral: CBPeripheral)
    
    func selectedService(service: CBService)
    func selectedCharacteristic(characteristic: CBCharacteristic)
    

}
