
//
//  ServiceViewController.swift
//  BLEServiceBrowser
//
//  Created by Spider on 11/4/15.
//  Copyright © 2015 Spider. All rights reserved.
//

import UIKit
import CoreBluetooth

class ServiceViewController: UITableViewController, SelectionDelegate, UISplitViewControllerDelegate {

    var objects :NSMutableArray = []
    var adapter: BLEAdapter?
    var service: CBService?
    var peripheral: CBPeripheral?
    var masterPopoverController: UIPopoverController?
    var delegate: SelectionDelegate?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
        
        
//        let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
//        appDelegate.setServiceViewDelegate(self)
        
        adapter = sharedBLEAdapter
        peripheral = service?.peripheral
        adapter?.activePeripheral = peripheral
        self.configureView()
        adapter?.getAllCharacteristicsForService(peripheral!, service: service!)
        
    }
    
    override func viewWillAppear(animated: Bool) {
        
        
        let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
        appDelegate.setServiceViewDelegate(self)
        
        
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func configureView()
    {
        adapter?.svController = self
        if(service != nil)
        {
            let strTitle = adapter?.CBUUIDToNSString((service?.UUID)!)
            self.title = strTitle as? String
        }
    }
    
    func AlCharacteristics(charcterArrays: NSArray)
    {
        for charcter in charcterArrays{
            objects.insertObject(charcter, atIndex: 0)
            let indexPath = NSIndexPath(forRow: 0, inSection: 0)
            var indxesPath:[NSIndexPath] = [NSIndexPath]()
            indxesPath.append(indexPath)
            
            //            self.serviceTableViewOutlet.numberOfRowsInSection(0) = self.serviceTableViewOutlet.numberOfRowsInSection(0) + 1;
            self.tableView.beginUpdates()
            self.tableView.insertRowsAtIndexPaths(indxesPath, withRowAnimation: UITableViewRowAnimation.Automatic)
            self.tableView.endUpdates()
            
            print("KeyfobViewController Characteristic found with UUID: %@", charcter.UUID)
        }
    }

    // MARK: - Table view data source

    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return objects.count
    }

 
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("serviceCell")! as UITableViewCell
        let aCharacteristic = objects.objectAtIndex(indexPath.row) as! CBCharacteristic
        cell.textLabel!.text =  adapter?.CBUUIDToNSString(aCharacteristic.UUID) as? String
//        cell.textLabel!.text = adapter?.GetServiceName(aCharacteristic.UUID)
//        cell.detailTextLabel!.text = aCharacteristic.UUID.data.description
        
        return cell
    }


    
    // Override to support conditional editing of the table view.
    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return false
    }

    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
    }

    /*
    // Override to support editing the table view.
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if editingStyle == .Delete {
            // Delete the row from the data source
            tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
        } else if editingStyle == .Insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(tableView: UITableView, moveRowAtIndexPath fromIndexPath: NSIndexPath, toIndexPath: NSIndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(tableView: UITableView, canMoveRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
//        ToCharView
        if(segue.identifier == "ToCharView")
        {
            let charCtrl = segue.destinationViewController as! CharViewController
            let indexPath = self.tableView.indexPathForSelectedRow! as NSIndexPath
            let charObject = objects.objectAtIndex(indexPath.row) as! CBCharacteristic
            charCtrl.characteristic = charObject
        }
 
    }
    
    // mark Selection Delegate
    
    func ClearUI(clear: Bool)
    {
        
    }
    func selectedPeripheral(peripheral: CBPeripheral)
    {
        
    }
    
    func selectedService(service: CBService)
    {
        self.service = service
        self.configureView()
    }
    
    func selectedCharacteristic(characteristic: CBCharacteristic)
    {
        
    }
    
    func splitViewController(svc: UISplitViewController, willHideViewController aViewController: UIViewController, withBarButtonItem barButtonItem: UIBarButtonItem, forPopoverController pc: UIPopoverController) {
        
        barButtonItem.title = "Scan"
        self.navigationItem.setLeftBarButtonItem(barButtonItem, animated: true)
        self.navigationItem.leftItemsSupplementBackButton = true
        self.masterPopoverController = pc
    }
    
    func splitViewController(svc: UISplitViewController, willShowViewController aViewController: UIViewController, invalidatingBarButtonItem barButtonItem: UIBarButtonItem) {
        self.navigationItem.setLeftBarButtonItem(nil, animated: true)
        self.masterPopoverController = nil
    }

}
